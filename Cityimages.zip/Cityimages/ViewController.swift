//
//  ViewController.swift
//  Cityimages
//
//  Created by 陈浩扬 on 9/9/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func seattleimage(_ sender: Any) {
        imageView.image = UIImage(named: "seattle2")
    }
    
    @IBAction func Losanglesimage(_ sender: Any) {
        imageView.image = UIImage(named: "lsj")
    }
        
    
    @IBAction func austinimage(_ sender: Any) {
        imageView.image = UIImage(named: "asd")
    }
    
    @IBAction func newyorkimage(_ sender: Any) {
        imageView.image = UIImage(named: "ny")
    }
    
    @IBAction func lasvegasimage(_ sender: Any) {
        imageView.image = UIImage(named: "lswjs")
    }
}

